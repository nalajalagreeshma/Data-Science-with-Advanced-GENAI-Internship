# Read input
n = int(input())

# Print numbers from 1 to n consecutively
for i in range(1, n + 1):
    print(i, end='')