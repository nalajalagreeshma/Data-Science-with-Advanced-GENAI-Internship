# Read input
a = int(input())
b = int(input())

# Integer division
print(a // b)

# Float division
print(a / b)