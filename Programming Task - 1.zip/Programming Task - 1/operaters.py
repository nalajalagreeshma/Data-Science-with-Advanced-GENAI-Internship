# Read input
a = int(input())
b = int(input())

# Print results
print(a + b)  # Sum
print(a - b)  # Difference (a - b)
print(a * b)  # Product