# Read input
n = int(input())

# Loop through 0 to n-1 and print squares
for i in range(n):
    print(i**2)